﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Dari.Models
{
    public class Role
    {
    }
}